import { useState, useEffect } from "react";

function Banner() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const slides = [
    {
      image: "https://media-cdn-v2.laodong.vn/storage/newsportal/2024/6/7/1350164/Suzy-Quang-Cao-1.jpg",
      title: "The Boys",
      subtitle: "", 
      promos: [
        { code: "OFF30", discount: "30K", minSpend: "299K" },
        { code: "OFF70", discount: "70K", minSpend: "499K" },
        { code: "OFF150", discount: "150K", minSpend: "1499K" },
      ]
    },
    {
      image: "https://media.vneconomy.vn/images/upload/2022/11/23/cr7.png",
      title: "New Arrivals",
      subtitle: "", 
      promos: [
        { code: "NEW20", discount: "20K", minSpend: "199K" },
        { code: "NEW50", discount: "50K", minSpend: "399K" },
        { code: "NEW100", discount: "100K", minSpend: "999K" },
      ]
    },  
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [slides.length]);

  return (
    <div className=" container min-h-[700px] h-[700px] shadow-md px-0 py-0 object-cover">
      {slides.map((slide, index) => (
        <div
          key={index}
          className={`container mx-auto absolute w-full h-full transition-opacity duration-500 ${
            index === currentSlide ? "opacity-100" : "opacity-0"
          }`}
        >
          <div className=" container mx-auto absolute right-0  w-3/4 h-full object-cover ">
            <img
              src={slide.image} 
              alt={`Slide ${index + 1}`}
              className="w-full h-full object-cover object-left"
            />
          </div>  
          <div className="  mx-auto absolute inset-0 py-0 px-0  ">
            <div className=" mx-auto h-full flex items-center">
              <div className="text-black max-w-xl p-8" data-aos="fade-right">
                <h2 className="text-4xl md:text-5xl font-bold mb-4">
                  {slide.title}<br/>{slide.subtitle}
                </h2>
                
                <div className="space-y-2 mb-8 ">
                  {slide.promos.map((promo, idx) => (
                    <p key={idx} className="text-sm md:text-base">
                      Sử dụng <span className="text-yellow-400 font-semibold">Code {promo.code}</span>
                      {" "}giảm <strong>{promo.discount}</strong> đơn từ {promo.minSpend}
                    </p>
                  ))}
                </div>
                <a
                  href="/"
                  className="inline-flex items-center bg-white text-black px-6 py-3 rounded-full hover:bg-orange-400 transition-colors border-2 border-black"
                >
                  <span className="font-medium">MUA NGAY</span>
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L12.586 11H5a1 1 0 110-2h7.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
                  </svg>
                </a>
              </div>
            </div>
          </div>
        </div>
      ))}
      <div className=" absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
        {slides.map((_, index) => (
          <button
            key={index}
            className={`w-3 h-3 rounded-full transition-colors ${
              index === currentSlide ? "bg-white/50" : "bg-white"
            }`}
            onClick={() => setCurrentSlide(index)}
          />
        ))}
      </div>
    </div>
  );
}

export default Banner;