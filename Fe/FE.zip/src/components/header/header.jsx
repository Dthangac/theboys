import { useState, useEffect } from 'react';

function Header() {
  const [cuon, xulycuon] = useState(false);

  useEffect(() => {
    const cuon = () => {
      if (window.scrollY > 0) {
        xulycuon(true);
      } else {
        xulycuon(false);
      }
    };

    window.addEventListener('scroll', cuon);
    return () => window.removeEventListener('scroll', cuon);
  }, []);

  return (
    <div className={`container w-full mx-auto bg-white text-black py-0 px-0 shadow-md ${cuon ? 'fixed top-0 left-50 z-50' : 'fixed top-0 right-50 z-50'}`}>
      <div className="container mx-auto flex justify-between items-center">
        <div className="flex items-center">
          <img src="src/assets/7pmxhbhr.jpg" alt="TheBoys" className="h-[70px] w-[130px]" />
        </div>
            <nav className="nav">   
                <ul className="flex space-x-8">
                    <li className="relative group">
                            <a href="#" className="text-black hover:text-yellow-600 hover:underline decoration-1 decoration-black-200">NAM GIỚI</a>
                            <div className="absolute hidden group-hover:block bg-white shadow-lg py-4 w-48 left-0 z-50">
                                <ul className="p-2">
                                    <li><a href="/donghonam" className="block px-4 py-2 hover:bg-gray-100 hover:underline decoration-1 decoration-black-200">ĐỒNG HỒ NAM</a></li>
                                    <li><a href="#" className="block px-4 py-2 hover:bg-gray-200 hover:underline decoration-1 decoration-black-200 ">TRANG SỨC NAM</a></li>
                                    <li><a href="#" className="block px-4 py-2 hover:bg-gray-200 hover:underline decoration-1 decoration-black-200">DÂY ĐỒNG HỒ NAM</a></li>
                                    <li><a href="#" className="block px-4 py-2 hover:bg-gray-200 hover:underline decoration-1 decoration-black-200">BEST SELLERS</a></li>
                                    <li><a href="#" className="block px-4 py-2 hover:bg-gray-200 hover:underline decoration-1 decoration-black-200">NEW ARRIVALS</a></li>
                                </ul>
                            </div>
                        </li>
                        <li className="relative group">
                            <a href="#" className="text-black hover:text-yellow-600 hover:underline decoration-1 decoration-black-200">NỮ GIỚI</a>
                            <div className="absolute hidden group-hover:block bg-white shadow-lg py-4 w-48 left-0 z-50">
                                <ul className="p-2">  
                                    <li><a href="#" className="block px-4 py-2 hover:bg-gray-200 hover:underline decoration-1 decoration-black-200">ĐỒNG HỒ NỮ</a></li>
                                    <li><a href="#" className="block px-4 py-2 hover:bg-gray-200 hover:underline decoration-1 decoration-black-200">TRANG SỨC NỮ</a></li>
                                    <li><a href="#" className="block px-4 py-2 hover:bg-gray-200 hover:underline decoration-1 decoration-black-200">DÂY ĐỒNG HỒ NỮ</a></li>
                                    <li><a href="#" className="block px-4 py-2 hover:bg-gray-200 hover:underline decoration-1 decoration-black-200">BEST SELLERS</a></li>
                                    <li><a href="#" className="block px-4 py-2 hover:bg-gray-200 hover:underline decoration-1 decoration-black-200">NEW ARRIVALS</a></li>
                                </ul>
                            </div>
                        </li>
                        <li><a href="#" className="text-black hover:text-yellow-600 hover:underline decoration-1 decoration-black-200">COLLABORATION</a></li>
                        <li><a href="#" className="text-black hover:text-yellow-600 hover:underline decoration-1 decoration-black-200">QUÀ TẶNG</a></li>
                        <li><a href="#" className="text-black hover:text-yellow-600 hover:underline decoration-1 decoration-black-200">BEST SELLERS</a></li>
                        <li><a href="#" className="text-black hover:text-yellow-600 hover:underline decoration-1 decoration-black-200">BLOG</a></li>
                        <li><a href="#" className="text-black hover:text-yellow-600 hover:underline decoration-1 decoration-black-200">VỀ CHÚNG TÔI</a></li>
                    </ul>
        </nav>
        <div className="flex items-center space-x-6 m-1">
          <a href="#" className="hover:text-gray-600">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </a>
          <a href="#" className="hover:text-gray-600">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
            </svg>
          </a>
          <a href="#" className="hover:text-gray-600">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
            </svg>
          </a>
          <a href="#" className="hover:text-gray-600">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
            </svg>
          </a>
        </div>
      </div>
    </div>
  )
}

export default Header
