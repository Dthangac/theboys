import {useState } from "react";


function Baohanh() {
  const [messages] = useState([
    "🛡️ BẢO HÀNH trong 10 năm đối với sản phẩm Đồng Hồ",
    "🔄 ĐỔI TRẢ MIỄN PHÍ trong 3 ngày (Với lỗi từ nhà sản xuất)",
    "🚚 FREE SHIPPING đơn hàng > 499k",
    "🛡️ BẢO HÀNH"
  ]);

  return (
    <div className=" container w-full h-auto bg-[#f0caca] border-t border-b border-black shadow-md px-0 py-0">
    <div className="   w-auto h-[100px] text-black font-semibold text-center flex items-center justify-center bg-[#f0caca] overflow-hidden  animate-scroll  px-0 py-0 duration-300">
      {messages.map((msg, index) => (
        <div key={index} className="inline-block px-6 ">
          <span style={{color: 'black'}}>{msg}</span>
        </div>  
      ))}
    </div>
    </div>
  );
}

export default Baohanh;
