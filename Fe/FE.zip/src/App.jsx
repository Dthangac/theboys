// eslint-disable-next-line no-unused-vars
import React from "react";
import { BrowserRouter as Router } from 'react-router-dom';
import Header from "./components/header/header";
import Footer from "./components/footer/footer";
import Banner from "./components/banner/banner";
import DanhMuchot from "./components/main/hotcate";
import BannerPro from "./components/main/catehot";
import Baohanh from "./components/main/baohanh";
const App = () => {
  return (
    <Router>
      <div className="container mx-auto">
        <Header/>
        <Banner/>
        <DanhMuchot/>
        <BannerPro/>
        <Baohanh/>
        <Footer/>
      </div>
    </Router>
  );
};

export default App;
